// 阻塞代码示例
const fs = require('fs');
const data = fs.readFileSync('file.txt', 'utf8');
console.log(data);

// 非阻塞代码示例
fs.readFile('file.txt', 'utf8', (err, data) => {
  if (err) throw err;
  console.log(data);
});
// 使用setTimeout
setTimeout(function () {
    console.log("来⾃回调的输出");
  }, 2000);
  
  console.log("来⾃全局作⽤域的输出");
  
  // 使用clearTimeout
  function changeText() {
    const h1 = document.querySelector("h1");
    h1.textContent = "来⾃回调的输出";
  }
  
  const timerID = setTimeout(changeText, 2000);
  
  document.querySelector("#cancelButton").addEventListener("click", function () {
    clearTimeout(timerID);
    console.log("定时器 ID:", timerID);
    console.log("定时器已取消");
  });
  // 使用setTimeout
setTimeout(function () {
    console.log("来⾃回调的输出");
  }, 2000);
  
  console.log("来⾃全局作⽤域的输出");
  
  // 使用clearTimeout
  function changeText() {
    const h1 = document.querySelector("h1");
    h1.textContent = "来⾃回调的输出";
  }
  
//   const timerID = setTimeout(changeText, 2000);
  
  document.querySelector("#cancelButton").addEventListener("click", function () {
    clearTimeout(timerID);
    console.log("定时器 ID:", timerID);
    console.log("定时器已取消");
  });
  let intervalID;

function startChange() {
  if (!intervalID) {
    intervalID = setInterval(changeColor, 1000);
  }
}

function changeColor() {
  if (document.body.style.backgroundColor !== "black") {
    document.body.style.backgroundColor = "black";
    document.body.style.color = "white";
  } else {
    document.body.style.backgroundColor = "white";
    document.body.style.color = "black";
  }
}

document.getElementById("start").addEventListener("click", startChange);

function stopChange() {
  clearInterval(intervalID);
}

document.getElementById("stop").addEventListener("click", stopChange);

function changeRandomColor() {
  const randomColor = Math.floor(Math.random() * 16777215).toString(16);
  document.body.style.backgroundColor = `#${randomColor}`;
}

// Update startChange to use changeRandomColor
// intervalID = setInterval(changeRandomColor, 1000);
document.querySelector("button").addEventListener("click", toggle);

function toggle(e) {
  e.target.classList.toggle("danger");
}

const posts = [
  { title: "帖子一", body: "这是帖子一" },
  { title: "帖子二", body: "这是帖子二" }
];

function getPosts() {
  setTimeout(() => {
    posts.forEach((post) => {
      const div = document.createElement("div");
      div.innerHTML = `<h3>${post.title}</h3><p>${post.body}</p>`;
      document.querySelector("#posts").appendChild(div);
    });
  }, 1000);
}

function createPost(post, cb) {
  setTimeout(() => {
    posts.push(post);
    cb();
  }, 2000);
}

createPost({ title: "帖子三", body: "这是帖子三" }, getPosts);
var xhr = new XMLHttpRequest();
xhr.open('GET', './movies.json');
xhr.onreadystatechange = function () {
  if (this.readyState === 4 && this.status === 200) {
    const data = JSON.parse(this.responseText);
    data.forEach((movie) => {
      const li = document.createElement('li');
      li.innerHTML = `<strong>${movie.name}</strong> - ${movie.year}`;
      document.querySelector('#results').appendChild(li);
    });
  }
};
xhr.send();
const jokeEl = document.getElementById('joke');
const jokeBtn = document.getElementById('joke-btn');

jokeBtn.addEventListener('click', generateJoke);

document.addEventListener('DOMContentLoaded', generateJoke);

function generateJoke() {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', 'https://api.chucknorris.io/jokes/random', true);
  xhr.onreadystatechange = function () {
    if (this.readyState === 4) {
      if (this.status === 200) {
        const joke = JSON.parse(this.responseText).value;
        jokeEl.innerHTML = joke;
      } else {
        jokeEl.innerHTML = '出现错误，不好笑。';
      }
    }
  };
  xhr.send();
}
function getData(endpoint, cb) {
    const XHR = new XMLHttpRequest();
    XHR.open("GET", endpoint);
    XHR.onreadystatechange = function () {
      if (this.readyState === 4 && this.status === 200) {
        cb(JSON.parse(this.responseText));
      }
    };
    setTimeout(() => {
      XHR.send();
    }, Math.floor(Math.random() * 3000) + 1000);
  }
  
  getData("./movies.json", (moviesData) => {
    console.log(moviesData);
    getData("./actors.json", (actorsData) => {
      console.log(actorsData);
      getData("./directors.json", (directorsData) => {
        console.log(directorsData);
      });
    });
  });