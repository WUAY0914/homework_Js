// 示例：User类
class User {
    constructor(name, email) {
        this.name = name;
        this.email = email;
    }

    createProfile() {
        console.log(`${this.name}已创建个人资料。`);
    }

    logOut() {
        console.log(`${this.name}已登出。`);
    }
}

// 创建User类的实例
const user1 = new User("Alice", "alice@example.com");
user1.createProfile(); // 输出: Alice已创建个人资料。
user1.logOut(); // 输出: Alice已登出。

// 示例：Rectangle构造函数
function Rectangle(name, width, height) {
    this.name = name;
    this.width = width;
    this.height = height;
    this.area = function () {
        return this.width * this.height;
    };
}

// 创建Rectangle对象的实例
const rect1 = new Rectangle("矩形 1", 10, 10);
console.log(rect1.area()); // 输出：100

// 示例：字符串字面量与字符串构造函数
const strLit = 'Hello';
const strObj = new String('Hello');

console.log(strLit.toUpperCase()); // 输出：HELLO
console.log(strObj.toUpperCase()); // 输出：HELLO

// 示例：Number构造函数
const numLit = 42;
const numObj = new Number(42);

console.log(numLit); // 输出：42
console.log(numObj); // 输出：[Number: 42]

// 示例：Boolean构造函数
const boolLit = true;
const boolObj = new Boolean(true);

console.log(boolLit); // 输出：true
console.log(boolObj); // 输出：[Boolean: true]

// 示例：Array构造函数
const arrLit = [1, 2, 3];
const arrObj = new Array(1, 2, 3);

console.log(arrLit); // 输出：[1, 2, 3]
console.log(arrObj); // 输出：[1, 2, 3]

// 示例：Function构造函数
function funcLit(x) {
    return x * x;
}
const funcObj = new Function('x', 'return x * x;');

console.log(funcLit(5)); // 输出：25
console.log(funcObj(5)); // 输出：25
