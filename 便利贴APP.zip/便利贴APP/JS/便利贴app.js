document.getElementById('addNoteBtn').addEventListener('click', function() {
    addNewNote();
});

function addNewNote(text = '') {
    const note = document.createElement('div');
    note.className = 'note';

    const innerHTML = `
        <div class="main ${text ? '' : 'hidden'}">${text}</div>
        <textarea class="textarea ${text ? 'hidden' : ''}"></textarea>
        <div class="controls">
            <i class="fa fa-trash delete-btn"></i>
            <i class="fa fa-edit edit-btn"></i>
        </div>
    `;

    note.innerHTML = innerHTML;
    document.body.appendChild(note);

    setupNoteEvents(note);
}

function setupNoteEvents(note) {
    const deleteBtn = note.querySelector('.delete-btn');
    const editBtn = note.querySelector('.edit-btn');
    const main = note.querySelector('.main');
    const textarea = note.querySelector('.textarea');

    deleteBtn.addEventListener('click', function() {
        note.remove();
        updateLocalStorage();
    });

    editBtn.addEventListener('click', function() {
        main.classList.toggle('hidden');
        textarea.classList.toggle('hidden');
        textarea.focus();
    });

    textarea.addEventListener('input', function(e) {
        const value = e.target.value;
        main.innerHTML = marked(value);
        updateLocalStorage();
    });
}

function updateLocalStorage() {
    const notes = Array.from(document.querySelectorAll('.note')).map(note => {
        const textarea = note.querySelector('.textarea');
        return textarea.value;
    });

    localStorage.setItem('notes', JSON.stringify(notes));
}

// Initialize notes from localStorage
window.onload = function() {
    const notes = JSON.parse(localStorage.getItem('notes')) || [];
    notes.forEach(text => {
        addNewNote(text);
    });
};