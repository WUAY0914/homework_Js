// 步骤6：处理对象属性
        // 设置构造函数
        function Rectangle(name, width, height) {
            this.name = name;
            this.width = width;
            this.height = height;
            this.area = function () {
                return this.width * this.height;
            };
        }

        // 创建矩形对象
        const rect1 = new Rectangle("矩形 1", 20, 20);
        const rect2 = new Rectangle("矩形 2", 30, 20);

        // 访问属性
        console.log(rect1.name); // 输出：矩形 1
        console.log(rect2.width); // 输出：30

        // 添加属性
        rect1.color = "红色";
        console.log(rect1); // 输出：Rectangle { name: '矩形 1', width: 20, height: 20, area: [Function], color: '红色' }

        // 添加方法
        rect2.perimeter = function () {
            return 2 * (rect2.width + rect2.height);
        };
        console.log(rect2.perimeter()); // 输出：100

        // 移除属性
        delete rect2.perimeter;
        console.log(rect2); // 输出：Rectangle { name: '矩形 2', width: 30, height: 20, area: [Function] }

        // 检查属性
        console.log(rect1.hasOwnProperty("color")); // 输出：true
        console.log(rect2.hasOwnProperty("color")); // 输出：false

        // 对象辅助方法
        console.log(Object.keys(rect1)); // 输出：[ 'name', 'width', 'height', 'area', 'color' ]
        console.log(Object.values(rect2)); // 输出：[ '矩形 2', 30, 20, [Function: area] ]
        console.log(Object.entries(rect1)); // 输出：[ ['name', '矩形 1'], ['width', 20], ['height', 20], ['area', [Function: area]], ['color', '红色'] ]

        // 遍历属性
        for (let [key, value] of Object.entries(rect1)) {
            console.log(`${key} - ${value}`);
        }

        // 过滤方法
        for (let [key, value] of Object.entries(rect1)) {
            if (typeof value !== "function") {
                console.log(`${key} - ${value}`);
            }
        }

        // 步骤7：原型与原型链
        // ⽰例：构造函数与原型
        const rect = new Rectangle("矩形 1", 20, 20);
        console.log(rect.__proto__); // 输出：{ constructor: [Function: Rectangle] }

        // 原型链
        console.log(rect.toString()); // 输出：[object Object]

        // 内置对象的原型
        const arr = [];
        const str = new String("Hello");
        const obj = {};

        console.log(arr.__proto__); // 输出：Array.prototype
        console.log(str.__proto__); // 输出：String.prototype
        console.log(obj.__proto__); // 输出：Object.prototype

        // 访问原型
        console.log(Object.getPrototypeOf(rect)); // 输出：{ constructor: [Function: Rectangle] }

        // 步骤8：向原型添加方法
        // 将 area 方法移至原型
        Rectangle.prototype.area = function () {
            return this.width * this.height;
        };

        // 向原型添加更多方法
        Rectangle.prototype.perimeter = function () {
            return 2 * (this.width + this.height);
        };
        Rectangle.prototype.isSquare = function () {
            return this.width === this.height;
        };
        Rectangle.prototype.changeName = function (newName) {
            this.name = newName;
        };

        // 测试原型方法
        const rect3 = new Rectangle("矩形 3", 10, 10);
        console.log(rect3.area()); // 输出：100
        console.log(rect3.perimeter()); // 输出：40
        rect3.changeName("测试矩形");
        console.log(rect3.name); // 输出：测试矩形

        // 步骤9：Object.create
        // 创建原型对象
        const rectanglePrototypes = {
            area: function () {
                return this.width * this.height;
            },
            perimeter: function () {
                return 2 * (this.width + this.height);
            },
            isSquare: function () {
                return this.width === this.height;
            }
        };

        // 创建工厂函数
        function createRectangle(width, height) {
            return Object.create(rectanglePrototypes, {
                width: {
                    value: width,
                    writable: true,
                    enumerable: true,
                    configurable: true
                },
                height: {
                    value: height,
                    writable: true,
                    enumerable: true,
                    configurable: true
                }
            });
        }

        // 创建矩形对象
        const rect4 = createRectangle(10, 20);
        console.log(rect4.area()); // 输出：200
        console.log(rect4.perimeter()); // 输出：60
        console.log(rect4.isSquare()); // 输出：false

        // 步骤10：原型继承与 call()
        // 创建 Shape 构造函数
        function Shape(name) {
            this.name = name;
        }

        // 向 Shape 原型添加方法
        Shape.prototype.logName = function () {
            console.log(`形状名称：${this.name}`);
        };

        // 矩形构造函数
        function Rectangle(name, width, height) {
            Shape.call(this, name);
            this.width = width;
            this.height = height;
        }

        // 继承 Shape 原型
        Rectangle.prototype = Object.create(Shape.prototype);
        Rectangle.prototype.constructor = Rectangle;

        // 重写 Rectangle 的 logName 方法
        Rectangle.prototype.logName = function () {
            console.log(`矩形名称：${this.name}`);
        };

        // 圆形构造函数
        function Circle(name, radius) {
            Shape.call(this, name);
            this.radius = radius;
        }

        // 继承 Shape 原型
        Circle.prototype = Object.create(Shape.prototype);
        Circle.prototype.constructor = Circle;

        // 测试继承
        const rect5 = new Rectangle("矩形 5", 20, 30);
        const circle = new Circle("圆形 1", 15);
        rect5.logName(); // 输出：矩形名称：矩形 5
        circle.logName(); // 输出：形状名称：圆形 1